import csv
import json

teams = []

with open('team_details.csv', mode='r') as f:
    csvFile = csv.reader(f)

    for (i,line) in enumerate(csvFile):
        if i==0: continue
        roster = line[5:]
        roster = list(filter(lambda x: len(x), roster))
        teams.append({
            'team_name': line[0],
            'division': line[1],
            'team_code': line[2],
            'city_of_origin': line[3],
            'logo': line[4],
            'roster': roster
        })


file = open('team_details.json', 'w')
file.write(json.dumps(teams))