module.exports = {
    secret: 'sakkath-secret-key'
}